#!/usr/bin/env python3
"""Diagnostic tests for validate_island.py (standard library only).

These tests supplement, but do not replace, the analytic enclosure arguments
in the paper and the proof assertions in validate_island.py.
"""
import random
import unittest
from fractions import Fraction as Q
import validate_island as v


def contains(interval, rational):
    return Q(interval.lo,v.SCALE) <= rational <= Q(interval.hi,v.SCALE)


class IntervalTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        v.PI=v.pi_interval()

    def test_rational_operations(self):
        random.seed(4187)
        for _ in range(250):
            a,b=sorted(Q(random.randint(-100,100),random.randint(1,31)) for _ in range(2))
            c,d=sorted(Q(random.randint(-100,100),random.randint(1,31)) for _ in range(2))
            X,Y=v.I.hull(a,b),v.I.hull(c,d)
            for x in (a,(a+b)/2,b):
                for y in (c,(c+d)/2,d):
                    self.assertTrue(contains(X+Y,x+y))
                    self.assertTrue(contains(X-Y,x-y))
                    self.assertTrue(contains(X*Y,x*y))
                    if not Y.contains_zero():
                        self.assertTrue(contains(X/Y,x/y))

    def test_square_roots(self):
        for q in [Q(0),Q(1),Q(2),Q(1,1000),Q(375,7)]:
            r=v.I(q).sqrt()
            self.assertLessEqual(Q(r.lo,v.SCALE)**2,q)
            self.assertGreaterEqual(Q(r.hi,v.SCALE)**2,q)

    def test_float_rejected(self):
        with self.assertRaises(TypeError):
            v.I(0.1)

    def test_zero_division_rejected(self):
        with self.assertRaises(ArithmeticError):
            v.I(1)/v.I.hull(-1,1)
        with self.assertRaises(ArithmeticError):
            v.C(1)/v.C(0)

    def test_known_trigonometric_values(self):
        for x,s,c in [(v.I(0),0,1),(v.PI/2,1,0),(v.PI,0,-1),(2*v.PI,0,1)]:
            sx,cx=v.sincos(x)
            self.assertTrue(contains(sx,Q(s)))
            self.assertTrue(contains(cx,Q(c)))

    def test_trigonometric_symmetries(self):
        for q in [Q(1,3),Q(5,2),Q(123,5),Q(-48,7)]:
            s,c=v.sincos(v.I(q))
            sn,cn=v.sincos(v.I(-q))
            self.assertTrue(s.overlaps(-sn))
            self.assertTrue(c.overlaps(cn))
            self.assertTrue((s*s+c*c-1).contains_zero())

    def test_ordinary_jet_coefficients(self):
        x=v.Jet({(1,0):1}); y=v.Jet({(0,1):1})
        J=(x+y)**3
        for mon,expected in [((3,0),1),((2,1),3),((1,2),3),((0,3),1)]:
            self.assertTrue(contains(J.c[mon],Q(expected)))
        S=x.sin()
        self.assertTrue(contains(S.c[1,0],Q(1)))
        self.assertTrue(contains(S.c[3,0],Q(-1,6)))
        self.assertTrue(contains(S.c[2,0],Q(0)))

    def test_twist_survives_nonlinear_symplectic_conjugacy(self):
        # N(z)=lambda*z+i*tau*lambda*z*|z|^2, tau=7.
        # H(u,v)=(u,v+t*u^2), t=3/2, is exactly symplectic.
        # Compute f=H o N o H^(-1) through degree three, then recover tau.
        u=v.Jet({(1,0):1}); w=v.Jet({(0,1):1})
        a,b,t,tau=v.I(Q(3,5)),v.I(Q(4,5)),v.I(Q(3,2)),v.I(7)
        v0=w-t*(u**2)
        r2=u**2+v0**2
        nx=a*u-b*v0-tau*(b*u+a*v0)*r2
        ny=b*u+a*v0+tau*(a*u-b*v0)*r2
        fx,fy=nx,ny+t*(nx**2)
        q1,q2=v.C(Q(1,2)),v.C(0,Q(-1,2))
        complex_jet=v.complex_coefficients((fx,fy),q1,q2)
        answer=v.birkhoff(complex_jet,v.C(a,b))
        self.assertFalse(answer['a20'].abs2().contains_zero())
        self.assertTrue(contains(answer['b21_over_lambda'].im,Q(7)))
        self.assertTrue(answer['b21_over_lambda'].im.strictly_inside('6.999','7.001'))
        self.assertTrue(answer['b21_over_lambda'].re.contains_zero())


if __name__=='__main__':
    unittest.main(verbosity=2)
