#!/usr/bin/env python3
"""Reproducible interval certificate for the (1,1) kicked Harper six-cycle.

Python >= 3.10; standard library only. No floating-point arithmetic is used
in any proof test. All interval endpoints are integer multiples of 2**(-bits).
Run: python3 validate_island.py --bits 256 --output certificate_256.json

The interval/Taylor implementation is intentionally small and auditable.
A successful run validates the orbit, its least period, its ellipticity,
and a nonzero first Birkhoff coefficient in a specified symplectic basis.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import platform
from fractions import Fraction
from pathlib import Path
from typing import Any

BITS = 256
SCALE = 1 << BITS


def need(condition: bool, message: str) -> None:
    """Proof checks cannot be disabled by python -O."""
    if not condition:
        raise ArithmeticError(message)


def ceildiv(a: int, b: int) -> int:
    if b == 0:
        raise ZeroDivisionError
    return -((-a) // b)


class I:
    """Closed outward-rounded real interval [lo/SCALE, hi/SCALE]."""
    __slots__ = ('lo', 'hi')

    def __init__(self, value: int | str | Fraction | I = 0):
        if isinstance(value, I):
            self.lo, self.hi = value.lo, value.hi
        else:
            if isinstance(value, float):
                raise TypeError('Use integer, Fraction, or decimal string, not float.')
            q = Fraction(value)
            self.lo = q.numerator * SCALE // q.denominator
            self.hi = ceildiv(q.numerator * SCALE, q.denominator)

    @classmethod
    def raw(cls, lo: int, hi: int) -> I:
        need(lo <= hi, 'Inverted interval')
        obj = object.__new__(cls)
        obj.lo, obj.hi = lo, hi
        return obj

    @classmethod
    def hull(cls, lo: int | str | Fraction, hi: int | str | Fraction) -> I:
        return cls.raw(I(lo).lo, I(hi).hi)

    def __add__(self, other: Any) -> I:
        if isinstance(other, (C, Jet)):
            return NotImplemented
        other = I(other)
        return I.raw(self.lo + other.lo, self.hi + other.hi)

    __radd__ = __add__

    def __neg__(self) -> I:
        return I.raw(-self.hi, -self.lo)

    def __sub__(self, other: Any) -> I:
        if isinstance(other, (C, Jet)):
            return NotImplemented
        return self + (-I(other))

    def __rsub__(self, other: Any) -> I:
        return I(other) + (-self)

    def __mul__(self, other: Any) -> I:
        if isinstance(other, (C, Jet)):
            return NotImplemented
        other = I(other)
        p = [self.lo*other.lo, self.lo*other.hi,
             self.hi*other.lo, self.hi*other.hi]
        return I.raw(min(p)//SCALE, ceildiv(max(p), SCALE))

    __rmul__ = __mul__

    def __truediv__(self, other: Any) -> I:
        if isinstance(other, C):
            return NotImplemented
        other = I(other)
        need(not other.contains_zero(), 'Division interval contains zero')
        low, high = [], []
        for a in (self.lo, self.hi):
            for b in (other.lo, other.hi):
                low.append((a*SCALE)//b)
                high.append(ceildiv(a*SCALE, b))
        return I.raw(min(low), max(high))

    def __rtruediv__(self, other: Any) -> I:
        return I(other)/self

    def __pow__(self, n: int) -> I:
        need(isinstance(n, int) and n >= 0, 'Only nonnegative integer powers')
        out = I(1)
        for _ in range(n):
            out = out*self
        return out

    def contains_zero(self) -> bool:
        return self.lo <= 0 <= self.hi

    def mag(self) -> int:
        """Exact numerator of max(abs(endpoints))."""
        return max(abs(self.lo), abs(self.hi))

    def abs_interval(self) -> I:
        low = 0 if self.contains_zero() else min(abs(self.lo), abs(self.hi))
        return I.raw(low, self.mag())

    def sqrt(self) -> I:
        need(self.lo >= 0, 'Square root of negative interval')
        low = math.isqrt(self.lo*SCALE)
        high = math.isqrt(self.hi*SCALE)
        if high*high < self.hi*SCALE:
            high += 1
        return I.raw(low, high)

    def strictly_inside(self, lo: int | str | Fraction, hi: int | str | Fraction) -> bool:
        return (Fraction(self.lo, SCALE) > Fraction(lo)
                and Fraction(self.hi, SCALE) < Fraction(hi))

    def overlaps(self, other: I) -> bool:
        return max(self.lo, other.lo) <= min(self.hi, other.hi)

    def decimal(self, places: int = 65) -> str:
        """Outward decimal display; never used to make a proof decision."""
        den = 10**places
        a = self.lo*den//SCALE
        b = ceildiv(self.hi*den, SCALE)
        def fmt(v: int) -> str:
            sign = '-' if v < 0 else ''
            v = abs(v)
            return f'{sign}{v//den}.{v%den:0{places}d}'
        return '['+fmt(a)+', '+fmt(b)+']'


def atan_inverse(q: int) -> I:
    """Alternating series, with explicit tail enclosure."""
    need(q >= 2, 'atan_inverse needs q >= 2')
    result = I(0)
    power, k = q, 0
    while True:
        term = I(Fraction(1, (2*k+1)*power))
        result = result + (term if k % 2 == 0 else -term)
        k += 1
        power *= q*q
        tail = I(Fraction(1, (2*k+1)*power))
        if tail.hi <= 1:
            return result + I.raw(-tail.hi, tail.hi)


def pi_interval() -> I:
    return 16*atan_inverse(5) - 4*atan_inverse(239)


PI = I(0)


def sincos(x: I) -> tuple[I, I]:
    """Certified sin/cos via range reduction, point Taylor, Lipschitz bound.

    Range reduction uses an interval enclosure of true pi. Taylor remainder
    bounds are the magnitudes of the first omitted nonzero terms; this is
    also a Lagrange bound because the intervening Taylor coefficient is zero.
    """
    # k is merely an integer choice, not a purported interval rounding step.
    mid = (x.lo+x.hi)//2
    pi_mid = (PI.lo+PI.hi)//2
    k = (mid + pi_mid)//(2*pi_mid)
    reduced = x - 2*k*PI
    tmid = (reduced.lo+reduced.hi)//2
    radius = max(tmid-reduced.lo, reduced.hi-tmid)
    t = I.raw(tmid, tmid)
    need(t.mag() <= 4*SCALE, 'Unexpected trigonometric reduction range')
    t2 = t*t
    st, ct = t, I(1)
    ss, cc = st, ct
    for j in range(1, BITS+1):
        snext = -st*t2/((2*j)*(2*j+1))
        cnext = -ct*t2/((2*j-1)*(2*j))
        if max(snext.mag(), cnext.mag()) <= 4:
            ss = ss + I.raw(-snext.mag()-radius, snext.mag()+radius)
            cc = cc + I.raw(-cnext.mag()-radius, cnext.mag()+radius)
            return ss, cc
        ss, cc = ss+snext, cc+cnext
        st, ct = snext, cnext
    raise ArithmeticError('Trigonometric series did not reach target')


class C:
    """Rectangular complex interval."""
    __slots__ = ('re', 'im')

    def __init__(self, re: Any = 0, im: Any = 0):
        if isinstance(re, C):
            self.re, self.im = re.re, re.im
        else:
            self.re, self.im = I(re), I(im)

    def __add__(self, other: Any) -> C:
        if isinstance(other, Jet):
            return NotImplemented
        other = C(other)
        return C(self.re+other.re, self.im+other.im)

    __radd__ = __add__

    def __neg__(self) -> C:
        return C(-self.re, -self.im)

    def __sub__(self, other: Any) -> C:
        if isinstance(other, Jet):
            return NotImplemented
        return self + (-C(other))

    def __rsub__(self, other: Any) -> C:
        return C(other)+(-self)

    def __mul__(self, other: Any) -> C:
        if isinstance(other, Jet):
            return NotImplemented
        other = C(other)
        return C(self.re*other.re-self.im*other.im,
                 self.re*other.im+self.im*other.re)

    __rmul__ = __mul__

    def conj(self) -> C:
        return C(self.re, -self.im)

    def abs2(self) -> I:
        # Squaring via abs_interval avoids an unnecessarily negative lower bound.
        return self.re.abs_interval()**2+self.im.abs_interval()**2

    def __truediv__(self, other: Any) -> C:
        other = C(other)
        den = other.abs2()
        need(den.lo > 0, 'Complex divisor is not separated from zero')
        numer = self*other.conj()
        return C(numer.re/den, numer.im/den)

    def __rtruediv__(self, other: Any) -> C:
        return C(other)/self

    def __pow__(self, n: int) -> C:
        need(isinstance(n, int) and n >= 0, 'Only nonnegative integer powers')
        out = C(1)
        for _ in range(n):
            out = out*self
        return out


MONS = [(j, k) for n in range(4) for j in range(n+1) for k in [n-j]]


class Jet:
    """Ordinary bivariate Taylor coefficients, truncated after degree three."""
    def __init__(self, coeff: dict[tuple[int, int], Any] | None = None, complex_: bool = False):
        self.complex = complex_
        scalar = C if complex_ else I
        self.c = {m: scalar(0) for m in MONS}
        if coeff:
            for m, value in coeff.items():
                need(m in self.c, 'Monomial outside jet')
                self.c[m] = scalar(value)

    def promote(self) -> Jet:
        return Jet(self.c, True)

    def __add__(self, other: Any) -> Jet:
        if not isinstance(other, Jet):
            other = Jet({(0, 0): other}, self.complex or isinstance(other, C))
        complex_ = self.complex or other.complex
        return Jet({m: self.c[m]+other.c[m] for m in MONS}, complex_)

    __radd__ = __add__

    def __neg__(self) -> Jet:
        return Jet({m: -self.c[m] for m in MONS}, self.complex)

    def __sub__(self, other: Any) -> Jet:
        return self+(-other)

    def __rsub__(self, other: Any) -> Jet:
        return -self+other

    def __mul__(self, other: Any) -> Jet:
        if not isinstance(other, Jet):
            return Jet({m: self.c[m]*other for m in MONS},
                       self.complex or isinstance(other, C))
        complex_ = self.complex or other.complex
        out = Jet(complex_=complex_)
        for (a, b) in MONS:
            for (c, d) in MONS:
                if a+b+c+d <= 3:
                    out.c[a+c, b+d] = out.c[a+c, b+d]+self.c[a,b]*other.c[c,d]
        return out

    __rmul__ = __mul__

    def __truediv__(self, other: Any) -> Jet:
        return Jet({m: self.c[m]/other for m in MONS},
                   self.complex or isinstance(other, C))

    def __pow__(self, n: int) -> Jet:
        out = Jet({(0, 0): 1}, self.complex)
        for _ in range(n):
            out = out*self
        return out

    def sin(self) -> Jet:
        need(not self.complex, 'Jet sin only needed for real jets')
        s, c = sincos(self.c[0,0])
        delta = Jet({m: value for m, value in self.c.items() if m != (0,0)})
        return s + delta*c - (delta**2)*(s/2) - (delta**3)*(c/6)


def matmul(A: list[list[I]], B: list[list[I]]) -> list[list[I]]:
    return [[sum((A[i][k]*B[k][j] for k in range(2)), I(0))
             for j in range(2)] for i in range(2)]


def matvec(A: list[list[I]], v: list[I]) -> list[I]:
    return [sum((A[i][j]*v[j] for j in range(2)), I(0)) for i in range(2)]


def identity() -> list[list[I]]:
    return [[I(1), I(0)], [I(0), I(1)]]


def iterate_derivative(z: list[I], n: int) -> tuple[list[I], list[list[I]]]:
    x, y = z
    M = identity()
    for _ in range(n):
        sx, cx = sincos(2*PI*x)
        y1 = y+sx
        sy, cy = sincos(2*PI*y1)
        a, b = 2*PI*cy, 2*PI*cx
        D = [[1+a*b, a], [b, I(1)]]
        M = matmul(D, M)
        x, y = x+sy, y1
    return [x, y], M


def iterate_jets(box: list[I]) -> tuple[Jet, Jet]:
    x = Jet({(0,0): box[0], (1,0): 1})
    y = Jet({(0,0): box[1], (0,1): 1})
    for _ in range(6):
        y = y+(x*(2*PI)).sin()
        x = x+(y*(2*PI)).sin()
    return x, y


CX = '0.27474448332000881878050615161797640957394247787842890490043558664838204815059897'
CY = '0.092588780576427956472961292120881745888037901834466710224563523023949661988119064'
PRE = [
    ['0.4135021217575490703333801035742412075797',
     '-2.399328010952348941913855704225548696173'],
    ['0.3480268316536689025396153232872661506545',
     '-1.413502121757549070333380103574241207580'],
]


def box_at(radius: str) -> list[I]:
    r = Fraction(radius)
    return [I.hull(Fraction(v)-r, Fraction(v)+r) for v in (CX, CY)]


def krawczyk(radius: str) -> dict[str, Any]:
    center = [I(CX), I(CY)]
    box = box_at(radius)
    Cmat = [[I(v) for v in row] for row in PRE]
    Fc, _ = iterate_derivative(center, 6)
    residual = [Fc[0]-center[0]-3, Fc[1]-center[1]]
    _, DX = iterate_derivative(box, 6)
    DG = [[DX[i][j]-(1 if i == j else 0) for j in range(2)] for i in range(2)]
    CDG = matmul(Cmat, DG)
    E = [[(1 if i == j else 0)-CDG[i][j] for j in range(2)] for i in range(2)]
    dev = [I.hull(-Fraction(radius), Fraction(radius)) for _ in range(2)]
    Eg = matvec(E, dev)
    Cr = matvec(Cmat, residual)
    offset = [-Cr[j]+Eg[j] for j in range(2)]
    norm_num = max(sum(E[i][j].mag() for j in range(2)) for i in range(2))
    norm = I.raw(0, norm_num)
    r_exact = Fraction(radius)
    need(all(Fraction(v.mag(), SCALE) < r_exact for v in offset),
         'Krawczyk image not strictly inside exact rational box')
    need(norm_num < SCALE, 'Contraction bound failed')
    return {'radius': radius, 'residual': residual, 'offset': offset,
            'E': E, 'contraction_upper': norm, 'jacobian': DX}


def complex_coefficients(jets: tuple[Jet, Jet], q1: C, q2: C) -> Jet:
    U = Jet({(1,0): q1, (0,1): q1.conj()}, True)
    V = Jet({(1,0): q2, (0,1): q2.conj()}, True)
    powers_u = [U**j for j in range(4)]
    powers_v = [V**j for j in range(4)]
    out = []
    for J in jets:
        result = Jet(complex_=True)
        for (j,k) in MONS:
            if j+k:
                result = result+(powers_u[j]*powers_v[k])*J.c[j,k]
        out.append(result)
    determinant = q1*q2.conj()-q1.conj()*q2
    return (out[0]*q2.conj()-out[1]*q1.conj())/determinant


def birkhoff(jet: Jet, lam: C) -> dict[str, Any]:
    a20, a11, a02, a21 = (jet.c[m] for m in ((2,0),(1,1),(0,2),(2,1)))
    denominators = [lam**2-lam, 1-lam, lam.conj()**2-lam]
    need(all(d.abs2().lo > 0 for d in denominators), 'Quadratic resonance')
    h20, h11, h02 = [a/d for a,d in zip((a20,a11,a02), denominators)]
    b21 = a21+2*a20*h11+a11*h20+a11*h11.conj()+2*a02*h02.conj()
    b_over_lam = b21/lam
    alternate = (a21/lam + (1-2*lam)*a20*a11/(lam**2*(lam-1))
                 + a11.abs2()/(lam-1) + 2*a02.abs2()/(lam**3-1))
    need(b_over_lam.re.overlaps(alternate.re)
         and b_over_lam.im.overlaps(alternate.im), 'Birkhoff algebraic cross-check')
    need(b_over_lam.re.contains_zero(), 'Real part consistency check')
    return {'a20': a20, 'a11': a11, 'a02': a02, 'a21': a21,
            'h20': h20, 'h11': h11, 'h02': h02,
            'b21': b21, 'b21_over_lambda': b_over_lam,
            'alternate': alternate, 'denominators': denominators}


def encode(obj: Any) -> Any:
    if isinstance(obj, I):
        return {'lo': str(obj.lo), 'hi': str(obj.hi), 'decimal': obj.decimal()}
    if isinstance(obj, C):
        return {'real': encode(obj.re), 'imag': encode(obj.im)}
    if isinstance(obj, dict):
        return {str(k): encode(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [encode(v) for v in obj]
    return obj


def run(bits: int) -> dict[str, Any]:
    global BITS, SCALE, PI
    need(bits >= 256, 'Use at least 256 binary fractional bits')
    BITS, SCALE = bits, 1 << bits
    PI = pi_interval()
    detC = (Fraction(PRE[0][0])*Fraction(PRE[1][1])
            - Fraction(PRE[0][1])*Fraction(PRE[1][0]))
    need(detC != 0, 'Exact preconditioner is singular')
    runs = [krawczyk(r) for r in ('1e-30','1e-48','1e-60')]
    for kr, e_bound, k_bound in zip(runs, ('1e-18','1e-36','1e-38'),
                                      ('1e-48','1e-64','1e-64')):
        need(kr['contraction_upper'].strictly_inside(-1, e_bound),
             'Published contraction bound failed')
        need(all(value.strictly_inside(-Fraction(k_bound), Fraction(k_bound))
                 for value in kr['offset']),
             'Published Krawczyk offset bound failed')
    final_box = box_at('1e-60')
    two, _ = iterate_derivative(final_box, 2)
    displacement = two[1]-final_box[1]
    need(displacement.strictly_inside('-0.010319188238','-0.010319188237'),
         'Period-two exclusion failed')
    jets = iterate_jets(final_box)
    M = [[J.c[1,0], J.c[0,1]] for J in jets]
    # Cross-check the linear jet against a separate chain-rule propagation.
    _, Mc = iterate_derivative(final_box, 6)
    need(all(M[i][j].overlaps(Mc[i][j]) for i in range(2) for j in range(2)),
         'Jacobian/linear-jet cross-check failed')
    A, B, Cval, D = M[0][0], M[0][1], M[1][0], M[1][1]
    trace = A+D
    need(trace.strictly_inside('-1.991309','-1.991308'), 'Ellipticity trace test')
    s = (1-(trace/2)**2).sqrt()
    need(s.lo > 0 and B.lo > 0, 'Eigenbasis determinant test')
    lam = C(trace/2,s)
    # The exact determinant of the derivative is one, proved from the shears.
    # The interval determinant check below is only an additional diagnostic.
    detM = A*D-B*Cval
    need((detM-1).contains_zero(), 'Area-preservation diagnostic failed')
    q1, q2 = C(B), lam-A
    raw_jet = complex_coefficients(jets, q1, q2)
    raw = birkhoff(raw_jet, lam)
    beta = raw['b21_over_lambda'].im
    need(raw['b21_over_lambda'].re.strictly_inside('-4e-35','4e-35'),
         'Published real-part diagnostic bound failed')
    need(beta.strictly_inside('600142873429.5456140196',
                              '600142873429.5456140198'),
         'Raw first Birkhoff coefficient enclosure failed')
    detS = -4*B*s
    need(detS.strictly_inside('-3.567294748','-3.567294747'), 'Real basis determinant')
    d = -detS
    tau = beta/detS
    need(tau.strictly_inside('-168234731311.063214153',
                             '-168234731311.063214152'),
         'Canonical twist enclosure failed')
    # Orientation is essential: zeta=sqrt(d)*conj(z), multiplier=conj(lam).
    q1can, q2can = q1.conj()/d.sqrt(), q2.conj()/d.sqrt()
    can_jet = complex_coefficients(jets, q1can, q2can)
    canonical = birkhoff(can_jet, lam.conj())
    tau_direct = canonical['b21_over_lambda'].im
    need(tau.overlaps(tau_direct), 'Canonical scaling cross-check failed')
    need(tau_direct.strictly_inside('-168234731311.063214153',
                                    '-168234731311.063214152'),
         'Direct canonical twist enclosure failed')
    result = {
        'bits': bits, 'endpoint_denominator': str(SCALE),
        'arithmetic': 'exact-integer outward dyadic intervals',
        'python': platform.python_version(),
        'checker_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'center': [CX,CY], 'preconditioner': PRE,
        'pi': PI, 'krawczyk': runs,
        'period_two_vertical': displacement,
        'jacobian_from_jet': M, 'determinant_diagnostic': detM, 'trace': trace,
        's': s, 'lambda': lam, 'detS': detS,
        'raw_birkhoff': raw, 'canonical_birkhoff': canonical,
        'tau_canonical_scaling': tau, 'tau_canonical_direct': tau_direct,
        'real_jets': [J.c for J in jets], 'status': 'ALL CHECKS PASSED',
    }
    return result


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--bits', type=int, default=256)
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    result = run(args.bits)
    print('Binary fractional bits:', args.bits)
    print('Exact input center:', CX, CY)
    for kr in result['krawczyk']:
        print('Krawczyk radius', kr['radius'])
        print('  contraction <=', kr['contraction_upper'].decimal(100))
        for j,value in enumerate(kr['offset']):
            print(f'  offset[{j}] =',value.decimal(100))
    for label, value in (
        ('Period-two vertical displacement', result['period_two_vertical']),
        ('Trace',result['trace']), ('det S',result['detS']),
        ('Im(b21/lambda)',result['raw_birkhoff']['b21_over_lambda'].im),
        ('Re(b21/lambda)',result['raw_birkhoff']['b21_over_lambda'].re),
        ('Canonical twist (scaling)', result['tau_canonical_scaling']),
        ('Canonical twist (direct)', result['tau_canonical_direct']),
    ):
        print(label+':',value.decimal())
    print(result['status'])
    if args.output:
        args.output.parent.mkdir(parents=True,exist_ok=True)
        args.output.write_text(json.dumps(encode(result),indent=2)+'\n')
        print('Certificate:',args.output.name)


if __name__ == '__main__':
    main()
