﻿Reproducible certificate: elliptic island for kicked Harper at (1,1)
--
The manuscript and checker use
y1 = y + sin(2*pi*x)
x1 = x + sin(2*pi*y1)
and validate a solution of F^6(p) = p + (3,0). All decimal input constants are exact rationals. The torus map has least period six at this point.
Files
main.tex is the single top-level manuscript source. Its bibliography is included in the same file. All computational material is in anc/ in the source archive:
    • validate_island.py: the complete outward-rounded dyadic interval verifier. 
    • test_validator.py: eight diagnostic tests, including recovery of a prescribed Birkhoff coefficient after a nonlinear symplectic conjugacy. 
    • certificate_256.json, certificate_384.json, certificate_512.json: exact interval endpoints and metadata from successful runs. 
    • validation_256.txt, validation_384.txt, validation_512.txt: execution logs. 
    • tests.txt: the recorded diagnostic-test output. 
    • README.md: this document. 
    • SHA256SUMS.txt: file-integrity hashes for the other computational files. 
The supplied compiled manuscript is distributed separately, not inside the source archive. Build products, font files, and the original uploaded draft are not part of this source package.
Run the verification
Python 3.10 or later is required; only the standard library is used. The recorded runs used Python 3.13.5. No SageMath, NumPy, MPFI, external mathematics library, network access, or installation step is needed.
From the directory containing the computational files:
sh python3 test_validator.py python3 validate_island.py --bits 256 --output rerun_256.json python3 validate_island.py --bits 384 --output rerun_384.json python3 validate_island.py --bits 512 --output rerun_512.json
Each validation must terminate with ALL CHECKS PASSED, and all eight diagnostic tests must pass. A failed proof condition raises an exception. Proof conditions are not implemented with Python assert, so they remain active under python -O. A nonzero exit status or an exception is a failed validation, irrespective of any partial decimal output printed before it.
The three precisions are separate consistency runs of the same implementation; they are not three independent implementations. The code also compares direct Jacobian propagation with the linear Taylor jet, evaluates two algebraically equivalent formulas for the cubic resonant coefficient, and recomputes that coefficient in a symplectically normalized basis. These diagnostics do not replace the interval-inclusion arguments and analytic proof in the manuscript.
What is certified
The Krawczyk test establishes a unique zero in the exact rational box of radius 1e-30 about the full center printed in the paper and source. Separate tests on nested boxes of radii 1e-48 and 1e-60 certify the same zero there. Derivatives and Taylor coefficients are enclosed on the entire final root box, rather than being evaluated only at the displayed center.
The checker proves the period-two displacement exclusion, a trace in (-1.991309, -1.991308), and the two coefficient enclosures
600142873429.5456140196 < Im(b21/lambda)
                       < 600142873429.5456140198

-168234731311.063214153 < tau_can
                        < -168234731311.063214152.
The raw eigenvector is q = (B, lambda-A) for the return derivative M = [[A,B],[C,D]]. If S = [2 Re(q), -2 Im(q)] and d = -det(S) > 0, the canonical linear coordinate is zeta = sqrt(d) * conjugate(z). Its multiplier is conjugate(lambda) and its coefficient is tau_can = Im(b21/lambda)/det(S). The complex conjugation is essential to the orientation and sign convention.
The exact equality Re(b21/lambda) = 0 follows from area preservation, as proved in the manuscript. A numerical interval containing zero is only a consistency check, not a proof of that equality.
The existence of the KAM curves, the pointwise zero exponents on their union, and non-ergodicity then follow from the analytic arguments in the manuscript. The checker does not compute invariant-curve parametrizations, certify a numerical lower bound on island area, prove the central multiplier Diophantine, or determine a parameter rectangle for the qualitative persistence corollary.
Reading the JSON certificates
Each real interval object has string-valued integer fields lo and hi. Divide these integers by the positive integer in the top-level endpoint_denominator field to recover its exact endpoints. The denominator is 2**bits.
The decimal field is an outward-rounded display for human inspection. It is not used in any proof decision. Complex intervals are represented by their real and imag interval components. real_jets records the ordinary Taylor coefficients; monomial (j,k) means the coefficient of xi1**j * xi2**k, with the factorial normalization already included.
checker_sha256 records the SHA-256 digest of the source bytes that generated the certificate. The pre-recorded files match the distributed checker. Edits to that source require fresh certificates and logs. A different Python version may change metadata without changing the mathematical endpoint calculations. A byte-for-byte match of an entire JSON file is therefore not the mathematical success criterion.
The interval operations use integer floor/ceiling rounding, integer square roots, Machin's formula with bounded arctangent series, and Taylor/Lipschitz bounds for sine and cosine. Python floating-point numbers are rejected as real interval inputs. Python's integer implementation and execution environment remain part of the trusted computing base; this is not a proof-assistant formalization.
Compile the manuscript
From the root of the unpacked source archive:
sh pdflatex -interaction=nonstopmode -halt-on-error main.tex pdflatex -interaction=nonstopmode -halt-on-error main.tex
Standard TeX packages used are amsart, lmodern, amsmath, amssymb, amsthm, mathtools, geometry, microtype, booktabs, array, hyperref, and url. The supplied PDF was successfully compiled and visually inspected.
